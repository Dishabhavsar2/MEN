var constants =(function () {
    
    constants.emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    constants.numberRegex = /^[0-9]+$/;
    constants.fullNa
    
    meRegx=/^[a-zA-Z]+ [a-zA-Z]+$/;
    return constants;
});

exports.constants = constants;
